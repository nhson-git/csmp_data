import software.amazon.awssdk.auth.credentials.AwsSessionCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.ec2.Ec2Client;
import software.amazon.awssdk.services.ec2.model.*;
import software.amazon.awssdk.services.sts.StsClient;
import software.amazon.awssdk.services.sts.model.AssumeRoleRequest;
import software.amazon.awssdk.services.sts.model.AssumeRoleResponse;
import software.amazon.awssdk.services.sts.model.Credentials;

import java.util.Map;
import java.util.stream.Collectors;

public class AWSResourceMonitor implements Runnable {

    private StsClient sts;
    private String eid;
    private String rArn;
    public AWSResourceMonitor(StsClient stsClient, String externalId, String roleArn ){
        sts = stsClient;
        eid = externalId;
        rArn = roleArn;
    }

    @Override
    public void run(){
        System.out.println(" AWSResourceMonitor Run >> ");

        while(true){
            System.out.println(">>>>>>>>>SSSSS");
//            AwsSessionCredentials awsCreds = this.GetAWSCreds(sts,  "Ec2AllService");
            AwsSessionCredentials awsCreds = this.GetAWSCreds(sts,  "SGInsMultyService");
            if (awsCreds == null ) return;

            Ec2Client ec2Client = Ec2Client.builder()
                    .region(Region.AP_NORTHEAST_2)
                    .credentialsProvider(StaticCredentialsProvider.create(awsCreds))
                    .build();


            GetEC2Client(Region.AP_NORTHEAST_2, awsCreds);

//            GetEC2Client(Region.AP_NORTHEAST_2, awsCreds);
            System.out.println(">>>>>>>>>EEEE");
            //waitMillis(1000 * 5);
        }
    }

    public static void waitMillis(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public AwsSessionCredentials GetAWSCreds(StsClient sts, String roleSessionName) {

        int SESSION_DURATION = 60 * 60;

        try {
            AssumeRoleRequest assumeRoleRequest = AssumeRoleRequest.builder()
                    .durationSeconds(SESSION_DURATION)
                    .roleArn(rArn)
                    .externalId(eid)
                    .roleSessionName(roleSessionName)
                    .build();

            AssumeRoleResponse assumeRoleResult = sts.assumeRole(assumeRoleRequest);
            Credentials sessionCredentials = assumeRoleResult.credentials();

            //Credentails 생성
            AwsSessionCredentials awsCreds = AwsSessionCredentials.create(
                    sessionCredentials.accessKeyId(),
                    sessionCredentials.secretAccessKey(),
                    sessionCredentials.sessionToken()
            );

            return awsCreds;
        } catch (Exception e) {
            System.out.println("Exception : " + e.getMessage());
            return null;
        }
    }
    public void GetEC2Client(Region region, AwsSessionCredentials awsCreds) {
        // EC2 정보 조회
        Ec2Client ec2Client = Ec2Client.builder()
                .region(region)
                .credentialsProvider(StaticCredentialsProvider.create(awsCreds))
                .build();

        String nextToken = null; //결과의 다음 페이지를 요청하는 토큰입니다.

        DescribeInstancesRequest request = DescribeInstancesRequest.builder()
                .maxResults(100)  // 5에서 1000
                .nextToken(nextToken)
                .build();

        //지정된 인스턴스 또는 모든 인스턴스를 설명합니다.
        DescribeInstancesResponse responseEc2 = ec2Client.describeInstances(request);

        System.out.println("Total Size : " + responseEc2.reservations().size());

        for (Reservation reservation : responseEc2.reservations()) {
            for (Instance instance : reservation.instances()) {
                Map<String, String> tagMap = instance.tags().stream().collect(Collectors.toMap(Tag::key, Tag::value));

                System.out.println("++++ tagMap : " + tagMap);
                System.out.println("++++ instance : " + instance);
                System.out.println("");
            }

        }

        ec2Client.close();
    }

}
