import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
import software.amazon.awssdk.auth.credentials.AwsSessionCredentials;
import software.amazon.awssdk.auth.credentials.ProfileCredentialsProvider;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.ec2.Ec2Client;
import software.amazon.awssdk.services.ec2.model.DescribeInstancesRequest;
import software.amazon.awssdk.services.ec2.model.DescribeInstancesResponse;
import software.amazon.awssdk.services.sts.StsClient;
import software.amazon.awssdk.services.sts.model.AssumeRoleRequest;
import software.amazon.awssdk.services.sts.model.AssumeRoleResponse;
import software.amazon.awssdk.services.sts.model.Credentials;

import java.util.ArrayList;
import java.util.HashMap;

public class test2 {

    public static void main(String[] args) {

        ArrayList<Region> regionList = new ArrayList<>();
        //regionList.add(Region.AF_SOUTH_1);
        //regionList.add(Region.AP_EAST_1);
        //regionList.add(Region.AP_NORTHEAST_1);
        regionList.add(Region.AP_NORTHEAST_2);
       // regionList.add(Region.AP_SOUTH_1);
       // regionList.add(Region.AP_SOUTHEAST_1);
       // regionList.add(Region.AP_SOUTHEAST_2);
       // regionList.add(Region.AWS_GLOBAL);
       // regionList.add(Region.AWS_CN_GLOBAL);
       // regionList.add(Region.AWS_ISO_B_GLOBAL);

        int SESSION_DURATION = 60 * 60;
        HashMap credStsMap = new HashMap();
        regionList.forEach(x ->{
            try {
                AwsCredentialsProvider credentialProvider = ProfileCredentialsProvider.create("default");
                StsClient sts = StsClient.builder()
                        .credentialsProvider(credentialProvider)
                        .region(x)
                        .build();

                System.out.println(x + " , " +sts);

                AssumeRoleRequest assumeRoleRequest = AssumeRoleRequest.builder()
                        .durationSeconds(SESSION_DURATION)
                        .roleArn("arn:aws:iam::404621520965:role/arnawsiam404621520965roleCSMP-ReadWrite-Role")
                        .externalId("c148b21c-01b9-42d0-sk58-2c921b5e0293")
                        .roleSessionName("Ec2AllService")
                        .build();

                System.out.println("sts : " + sts );
                AssumeRoleResponse assumeRoleResult = sts.assumeRole(assumeRoleRequest);
                System.out.println(">11" );
                Credentials sessionCredentials = assumeRoleResult.credentials();


                System.out.println(">2" );
                //Credentails 생성
                AwsSessionCredentials cred = AwsSessionCredentials.create(
                        sessionCredentials.accessKeyId(),
                        sessionCredentials.secretAccessKey(),
                        sessionCredentials.sessionToken()
                );


                // EC2 정보 조회
                Ec2Client ec2Client = Ec2Client.builder()
                        .region(x)
                        .credentialsProvider(StaticCredentialsProvider.create(cred))
                        .build();

                String nextToken = null; //결과의 다음 페이지를 요청하는 토큰입니다.

                DescribeInstancesRequest request = DescribeInstancesRequest.builder()
                        .maxResults(100)  // 5에서 1000
                        .nextToken(nextToken)
                        .build();
                System.out.println(">>22");
                DescribeInstancesResponse response =  ec2Client.describeInstances(request);
                System.out.println("response : " + response);

            }catch (Exception e) {
                e.printStackTrace();
                System.out.println(">> Exception : " + e.getMessage());
            }

        });







    }
}
