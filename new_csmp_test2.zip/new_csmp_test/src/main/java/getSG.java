import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
import software.amazon.awssdk.auth.credentials.AwsSessionCredentials;
import software.amazon.awssdk.auth.credentials.ProfileCredentialsProvider;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.ec2.Ec2Client;
import software.amazon.awssdk.services.ec2.model.*;
import software.amazon.awssdk.services.sts.StsClient;
import software.amazon.awssdk.services.sts.model.AssumeRoleRequest;
import software.amazon.awssdk.services.sts.model.AssumeRoleResponse;
import software.amazon.awssdk.services.sts.model.Credentials;

public class getSG {

    //public String rArn = "arn:aws:iam::938685826125:role/AWS-wshield";
    public String rArn = "arn:aws:iam::404621520965:role/csmp-dev";
   // public String eid = "wshield";
    public String eid = "csmp-dev";

    public static void main(String[] args) {

        new getSG().run();

    }
    public void run(){
        StsClient sts = getSts(Region.AP_NORTHEAST_2);

        test(sts);

    }
    public void test(StsClient sts){
        AwsSessionCredentials awsCreds = this.GetAWSCreds(sts,  "Ec2AllService");
        if (awsCreds == null ) return;

        Ec2Client ec2Client = Ec2Client.builder()
                .region(Region.AP_NORTHEAST_2)
                .credentialsProvider(StaticCredentialsProvider.create(awsCreds))
                .build();

        String nextToken = null; //결과의 다음 페이지를 요청하는 토큰입니다.

        DescribeInstancesRequest request = DescribeInstancesRequest.builder()
                .maxResults(100)  // 5에서 1000
                .nextToken(nextToken)
                .build();
        DescribeInstancesResponse response =  ec2Client.describeInstances(request);
        System.out.println("response : " + response);

    }
/*
    public void getSGInfo(StsClient sts){


        AwsSessionCredentials awsCreds = this.GetAWSCreds(sts,  "SGUpdateService2");
        if (awsCreds == null ) return;

        Ec2Client ec2Client = Ec2Client.builder()
                .region(Region.AP_NORTHEAST_2)
                .credentialsProvider(StaticCredentialsProvider.create(awsCreds))
                .build();

        RevokeSecurityGroupIngressRequest revokeSecurityGroupIngressRequest = RevokeSecurityGroupIngressRequest.builder()
                .groupId("sg-063ee1a8265a71d13")
                .ipPermissions(ipPerm)
                .build();

        ec2Client.revokeSecurityGroupIngress(revokeSecurityGroupIngressRequest);



        System.out.println(response);

    }
*/
    //4) SG Rule 정보 조회
    public void getSGRule(StsClient sts){
        AwsSessionCredentials awsCreds = this.GetAWSCreds(sts,  "SGUpdateRuleService");
        if (awsCreds == null ) return;

        Ec2Client ec2Client = Ec2Client.builder()
                .region(Region.AP_NORTHEAST_2)
                .credentialsProvider(StaticCredentialsProvider.create(awsCreds))
                .build();


        DescribeSecurityGroupsRequest describeSecurityGroupsRequest = DescribeSecurityGroupsRequest.builder()
                .nextToken(null)
               // .groupIds("sg-063ee1a8265a71d13") //특정 group ID 넣으면 해당 ID만 적용
                .build();

        DescribeSecurityGroupsResponse describeSecurityGroupsResponse = ec2Client.describeSecurityGroups(describeSecurityGroupsRequest);


        System.out.println(describeSecurityGroupsResponse);
    }

    //3) SG 삭제
    public void getSGDelete(StsClient sts){
        AwsSessionCredentials awsCreds = this.GetAWSCreds(sts,  "SGDeleteServices");
        if (awsCreds == null ) return;

        Ec2Client ec2Client = Ec2Client.builder()
                .region(Region.AP_NORTHEAST_2)
                .credentialsProvider(StaticCredentialsProvider.create(awsCreds))
                .build();

        DeleteSecurityGroupRequest deleteSecurityGroupRequest = DeleteSecurityGroupRequest.builder()
                .groupId("sg-0f3ebbf72411f1139")
                .build();

        DeleteSecurityGroupResponse deleteSecurityGroupResponse = ec2Client.deleteSecurityGroup(deleteSecurityGroupRequest);


        System.out.println(deleteSecurityGroupResponse);
        System.out.println(deleteSecurityGroupResponse.sdkHttpResponse().isSuccessful());
    }
    //2) SG 생성
    public void getSGCreate(StsClient sts){
        AwsSessionCredentials awsCreds = this.GetAWSCreds(sts,  "SGCreateWithRuleService");
        if (awsCreds == null ) return;

        Ec2Client ec2Client = Ec2Client.builder()
                .region(Region.AP_NORTHEAST_2)
                .credentialsProvider(StaticCredentialsProvider.create(awsCreds))
                .build();

        // 보안그룹 생성 s
        CreateSecurityGroupRequest createSecurityGroupRequest = CreateSecurityGroupRequest.builder()
                .vpcId("vpc-c150fea8")
                .groupName("sg_nh_son_test")
                .description("nh_son_test_kk")
                .build();

        CreateSecurityGroupResponse createSecurityGroupResponse = ec2Client.createSecurityGroup(createSecurityGroupRequest);

        System.out.println(createSecurityGroupResponse);
        System.out.println(createSecurityGroupResponse.sdkHttpResponse().isSuccessful());
    }
    //1) EC2 에 적용된 SG 확인
    public void getSGFromEc2(StsClient sts){
        AwsSessionCredentials awsCreds = this.GetAWSCreds(sts,  "SGInsMultyService");
        if (awsCreds == null ) return;

        Ec2Client ec2Client = Ec2Client.builder()
                .region(Region.AP_NORTHEAST_2)
                .credentialsProvider(StaticCredentialsProvider.create(awsCreds))
                .build();

        DescribeInstanceAttributeRequest describeInstanceAttributeRequest = DescribeInstanceAttributeRequest.builder()
                .instanceId("i-0225d7fdcb6cd4e8b")
                .attribute("groupSet")
                .build();

        DescribeInstanceAttributeResponse describeInstanceAttributeResponse = ec2Client.describeInstanceAttribute(describeInstanceAttributeRequest);

        System.out.println(describeInstanceAttributeResponse);
    }

    public StsClient getSts(Region r) {
        try {
            AwsCredentialsProvider credentialProvider = ProfileCredentialsProvider.create("dev");
            return StsClient.builder()
                    .credentialsProvider(credentialProvider)
                    .region(r)
                    .build();

        }catch (Exception e) {
            return null;
        }
    }

    public AwsSessionCredentials GetAWSCreds(StsClient sts, String roleSessionName) {

        int SESSION_DURATION = 60 * 60;

        try {
            AssumeRoleRequest assumeRoleRequest = AssumeRoleRequest.builder()
                    .durationSeconds(SESSION_DURATION)
                    .externalId(eid)  // cloud_connect_param1
                    .roleArn(rArn) // cloud_connect_param2
                    .roleSessionName(roleSessionName)
                    .build();

            AssumeRoleResponse assumeRoleResult = sts.assumeRole(assumeRoleRequest);
            Credentials sessionCredentials = assumeRoleResult.credentials();

            //Credentails 생성
            AwsSessionCredentials awsCreds = AwsSessionCredentials.create(
                    sessionCredentials.accessKeyId(),
                    sessionCredentials.secretAccessKey(),
                    sessionCredentials.sessionToken()
            );

            return awsCreds;
        } catch (Exception e) {
            System.out.println("Exception : " + e.getMessage());
            return null;
        }
    }
}
