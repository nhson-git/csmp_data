

import software.amazon.awssdk.auth.credentials.*;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.ec2.Ec2Client;
import software.amazon.awssdk.services.ec2.model.*;
import software.amazon.awssdk.services.rds.RdsClient;
import software.amazon.awssdk.services.rds.model.DescribeDbInstancesResponse;
import software.amazon.awssdk.services.sts.StsClient;
import software.amazon.awssdk.services.sts.model.AssumeRoleRequest;
import software.amazon.awssdk.services.sts.model.AssumeRoleResponse;
import software.amazon.awssdk.services.sts.model.Credentials;
import software.amazon.awssdk.services.xray.paginators.GetServiceGraphIterable;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * To run this Java V2 code example, ensure that you have setup your development environment, including your credentials.
 * <p>
 * For information, see this documentation topic:
 * <p>
 * https://docs.aws.amazon.com/sdk-for-java/latest/developer-guide/get-started.html
 */
public class test {


    public static void main(String[] args) {
        new test().run(args);
    }

    public void run(String[] args) {

        System.out.println(">>>> Run ");

        StsClient sts = getSts(Region.AP_NORTHEAST_2);
        if (sts == null) return;

/*
        AWSResourceMonitor awsMonitor = new AWSResourceMonitor(sts, "sk-poc", "arn:aws:iam::874505372147:role/AWS-ADT-sk-poc");
        Thread awsThread = new Thread(awsMonitor);
        awsThread.start();
*/

        AWSResourceMonitor awsMonitor2 = new AWSResourceMonitor(sts, "AWS-nhson", "arn:aws:iam::167450982106:role/AWS-nhson");
        Thread awsThread2 = new Thread(awsMonitor2);
        awsThread2.start();

    }

    public StsClient getSts(Region r) {
        try {
            AwsCredentialsProvider credentialProvider = ProfileCredentialsProvider.create("dev");
            return StsClient.builder()
                    .credentialsProvider(credentialProvider)
                    .region(r)
                    .build();

        }catch (Exception e) {
            return null;
        }
    }


}