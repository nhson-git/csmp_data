package restApiTest;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class restapi {

    public static void main(String[] args) {
      String json = "{\"cloud_account_id\":\"167450982106\",\"csp_id\":\"AWS\",\"vpc_id\":\"vpc-75a2631e\",\"group_name\":\"kk\",\"ipPermissions_out\":[],\"region_id\":\"ap-northeast-2\",\"ipPermissions_in\":[{\"ipprotocol\":\"TCP\",\"ipranges\":[{\"description\":\"2222\",\"cidrIp\":\"2.2.2.2/0\"}],\"fromport\":\"222\",\"toport\":\"222\"}],\"description\":\"kkkk\"}\"";

      try{
        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(json);
        System.out.println("obj  : " + obj);

      }catch (Exception e ){
          e.getStackTrace();
          System.out.println(e.getMessage());
      }
    }
    public static void main1(String[] args) {


        try {
            JSONObject obj = new JSONObject();
            obj.put("cloud_account_id", "167450982106");
            obj.put("csp_id", "AWS");

            String paramJson = obj.toString();
            // url : 127.0.0.1:8510/cmp
            URL url = new URL("http://127.0.0.1:8081/Json_UpdateSgRule");

            System.out.println(" url : " + url);

            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            // HTTP POST 메소드 설정
//				con.setRequestProperty("User-Agent", USER_AGENT);
            con.setDoOutput(true);// POST 파라미터 전달을 위한 설정
            // Send post request
            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
            wr.writeBytes(paramJson);
            wr.flush();
            wr.close();

            System.out.println(" con.getResponseCode() : " + con.getResponseCode());

            int responseCode = con.getResponseCode();
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine; StringBuffer response = new StringBuffer();
            while ((inputLine = in.readLine()) != null) { response.append(inputLine); } in.close();

            // print result
            System.out.println("HTTP 응답 코드 : " + responseCode);
            System.out.println("HTTP body : " + response.toString());



        }catch (Exception e) {

           System.out.println("send post ERROR...");
           System.out.println(e.getMessage());
            e.printStackTrace();
        }


    }

}